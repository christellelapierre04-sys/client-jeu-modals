Client minimal for Course des Modals
-----------------------------------
How to use (quick):
1. Upload this folder as a static site (Render static site, Netlify, or Vercel). 
2. Make sure the server URL in script.js is correct (variable SERVER_URL).
3. Open the site, create room (teacher) and join on student devices with the code.
Notes:
- Replace musique.mp3 with a Kahoot-like tune if you want sound.
- This client is intentionally simple for easy deployment and testing.
